function getUniqueLayerName(comp, baseName) {
    var existingNames = {};
    for (var i = 1; i <= comp.numLayers; i++) { existingNames[comp.layer(i).name] = true; }
    if (!existingNames[baseName]) return baseName;
    var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    for (var j = 0; j < alphabet.length; j++) {
        var testName = baseName + " " + alphabet.charAt(j);
        if (!existingNames[testName]) return testName;
    }
    var num = 1;
    while (true) {
        var testNameNum = baseName + " " + num;
        if (!existingNames[testNameNum]) return testNameNum;
        num++;
    }
}

function removeEffectSafe(layer, name) {
    var eff = layer.Effects.property(name);
    if (eff) eff.remove();
}

function makeGodRect(jsonString) {
    var params = JSON.parse(jsonString);
    var comp = app.project.activeItem;
    
    if (!comp || !(comp instanceof CompItem)) {
        alert("Please select or open a composition first!");
        return;
    }

    app.beginUndoGroup("Summon GodRect");

    var safeLayerName = getUniqueLayerName(comp, params.layerName);
    var shapeLayer = comp.layers.addShape();
    shapeLayer.name = safeLayerName;
    
    var finalMasterName = shapeLayer.name;
    var masterRef = "thisComp.layer('" + finalMasterName + "').";
    var godTag = "/* [GODRECT_TAG:" + finalMasterName + "] */\n";

    var contents = shapeLayer.property("ADBE Root Vectors Group");
    var group = contents.addProperty("ADBE Vector Group");
    group.name = params.groupName;
    var groupContents = group.property("ADBE Vectors Group");

    var rectPath = groupContents.addProperty("ADBE Vector Shape - Rect");
    rectPath.name = "Rect Path"; 

    var sizeExpr = ""; 
    if (params.hasSizeSliders) {
        var sliderW = shapeLayer.Effects.addProperty("ADBE Slider Control");
        sliderW.name = "Width"; sliderW.property(1).setValue(parseFloat(params.width));

        var sliderH = shapeLayer.Effects.addProperty("ADBE Slider Control");
        sliderH.name = "Height"; sliderH.property(1).setValue(parseFloat(params.height));

        rectPath.property("ADBE Vector Rect Size").expression = "var w = " + masterRef + "effect('Width')(1); var h = " + masterRef + "effect('Height')(1); [w, h];";
        sizeExpr = "var s = [" + masterRef + "effect('Width')(1), " + masterRef + "effect('Height')(1)]; ";
        
        var fillCtrl = shapeLayer.Effects.addProperty("ADBE Color Control");
        fillCtrl.name = "Fill Color"; fillCtrl.property(1).setValue([1, 0.2, 0.4, 1]); 

        if (params.hasStroke) {
            var strokeColorCtrl = shapeLayer.Effects.addProperty("ADBE Color Control");
            strokeColorCtrl.name = "Stroke Color"; strokeColorCtrl.property(1).setValue([1, 1, 1, 1]); 

            var strokeWidthCtrl = shapeLayer.Effects.addProperty("ADBE Slider Control");
            strokeWidthCtrl.name = "Stroke Width"; strokeWidthCtrl.property(1).setValue(5);
        }
    } else {
        rectPath.property("ADBE Vector Rect Size").setValue([parseFloat(params.width), parseFloat(params.height)]);
        sizeExpr = "var s = content('" + params.groupName + "').content('Rect Path').size; ";
    }

    if (params.hasConcave) {
        var scRadius = shapeLayer.Effects.addProperty("ADBE Slider Control"); scRadius.name = "Concave Radius"; scRadius.property(1).setValue(40);
        var scSmooth = shapeLayer.Effects.addProperty("ADBE Slider Control"); scSmooth.name = "Concave Smoothness"; scSmooth.property(1).setValue(15);
    }
    if (params.hasBevel) {
        var sbSize = shapeLayer.Effects.addProperty("ADBE Slider Control"); sbSize.name = "Bevel Size"; sbSize.property(1).setValue(30);
        var sbSmooth = shapeLayer.Effects.addProperty("ADBE Slider Control"); sbSmooth.name = "Bevel Smoothness"; sbSmooth.property(1).setValue(10);
    }

    if (params.hasConcave) {
        var cutsGroup = groupContents.addProperty("ADBE Vector Group"); cutsGroup.name = "Cuts";
        var cutsContents = cutsGroup.property("ADBE Vectors Group");
        
        var ellipse = cutsContents.addProperty("ADBE Vector Shape - Ellipse");
        ellipse.property("ADBE Vector Ellipse Size").expression = "var r = " + masterRef + "effect('Concave Radius')(1); [r*2, r*2]";
        ellipse.property("ADBE Vector Ellipse Position").expression = sizeExpr + "[-s[0]/2, -s[1]/2]";

        var rep1 = cutsContents.addProperty("ADBE Vector Filter - Repeater"); rep1.property("ADBE Vector Repeater Copies").setValue(2); rep1.property("Transform").property("Position").expression = sizeExpr + "[s[0], 0]";
        var rep2 = cutsContents.addProperty("ADBE Vector Filter - Repeater"); rep2.property("ADBE Vector Repeater Copies").setValue(2); rep2.property("Transform").property("Position").expression = sizeExpr + "[0, s[1]]";

        var mergePaths = groupContents.addProperty("ADBE Vector Filter - Merge"); mergePaths.property("ADBE Vector Merge Type").setValue(3); 
        var offsetInSmooth = groupContents.addProperty("ADBE Vector Filter - Offset"); offsetInSmooth.property("ADBE Vector Offset Amount").expression = masterRef + "effect('Concave Smoothness')(1) * -1";
        var offsetOutSmooth = groupContents.addProperty("ADBE Vector Filter - Offset"); offsetOutSmooth.property("ADBE Vector Offset Line Join").setValue(2); offsetOutSmooth.property("ADBE Vector Offset Amount").expression = masterRef + "effect('Concave Smoothness')(1)";
    }

    if (params.hasBevel) {
        var offsetInBevel = groupContents.addProperty("ADBE Vector Filter - Offset"); offsetInBevel.property("ADBE Vector Offset Amount").expression = masterRef + "effect('Bevel Size')(1) * -1";
        var offsetOutBevel = groupContents.addProperty("ADBE Vector Filter - Offset"); offsetOutBevel.property("ADBE Vector Offset Line Join").setValue(3); offsetOutBevel.property("ADBE Vector Offset Amount").expression = masterRef + "effect('Bevel Size')(1)";
        var roundCorners = groupContents.addProperty("ADBE Vector Filter - RC"); roundCorners.property("ADBE Vector RoundCorner Radius").expression = masterRef + "effect('Bevel Smoothness')(1)";
    }
    
    if (params.hasStroke) {
        var stroke = groupContents.addProperty("ADBE Vector Graphic - Stroke"); stroke.name = "Stroke";
        if (params.hasSizeSliders) {
            stroke.property("ADBE Vector Stroke Color").expression = masterRef + "effect('Stroke Color')(1)";
            stroke.property("ADBE Vector Stroke Width").expression = masterRef + "effect('Stroke Width')(1)";
        } else {
            stroke.property("ADBE Vector Stroke Color").setValue([1, 1, 1, 1]);
            stroke.property("ADBE Vector Stroke Width").setValue(5);
        }
    }

    var fill = groupContents.addProperty("ADBE Vector Graphic - Fill"); fill.name = "Fill";
    if (params.hasSizeSliders) {
        fill.property("ADBE Vector Fill Color").expression = masterRef + "effect('Fill Color')(1)";
    } else {
        fill.property("ADBE Vector Fill Color").setValue([1, 0.2, 0.4, 1]);
    }
    
    var posExpr = "";
    if (params.hasGrid) {
        var gridCols = shapeLayer.Effects.addProperty("ADBE Slider Control"); gridCols.name = "Grid Columns Limit"; gridCols.property(1).setValue(parseFloat(params.gridCols));
        var gridGapX = shapeLayer.Effects.addProperty("ADBE Slider Control"); gridGapX.name = "Grid Gap X"; gridGapX.property(1).setValue(parseFloat(params.gridGapX));
        var gridGapY = shapeLayer.Effects.addProperty("ADBE Slider Control"); gridGapY.name = "Grid Gap Y"; gridGapY.property(1).setValue(parseFloat(params.gridGapY));

        posExpr = 
            "const baseLayerName = '" + finalMasterName + "';\n" +
            "const isMaster = (thisLayer.name === baseLayerName);\n" +
            "//Смещение при расположении слоёв сверху-вниз в списке\n" +
            "const cols = Math.max(1, thisComp.layer(baseLayerName).effect('Grid Columns Limit')(1)); // Лимит слоев в одном ряду\n" +
            "const baseLayer = thisComp.layer(baseLayerName); // Ищем главный слой\n" +
            "const offset = [baseLayer.effect('Grid Gap X')(1), baseLayer.effect('Grid Gap Y')(1)]; // Берем шаг [X, Y]\n" +
            "const startPos = isMaster ? value : baseLayer.transform.position; // Координаты старта сетки\n" +
            "// Ищем номер в названии слоя\n" +
            "const masterMatch = baseLayer.name.match(/\\d+$/);\n" +
            "const masterNum = masterMatch ? parseInt(masterMatch[0], 10) : 1;\n" +
            "const matchNum = thisLayer.name.match(/\\d+$/);\n" +
            "const currentNum = matchNum ? parseInt(matchNum[0], 10) : 1;\n" +
            "const myNum = isMaster ? 0 : Math.max(1, currentNum - masterNum); // Порядковый номер дубликата\n" +
            "const myCol = myNum % cols; // Вычисляем колонку\n" +
            "const myRow = Math.floor(myNum / cols); // Вычисляем ряд\n" +
            "// Сдвигаем стартовую точку\n" +
            "startPos + [myCol * offset[0], myRow * offset[1]];";
            
        shapeLayer.property("Transform").property("Position").expression = godTag + posExpr;

        if (params.autoGenGrid) {
            var totalCount = parseInt(params.gridCols) * parseInt(params.gridRows);
            var prevLayer = shapeLayer;
            
            for (var i = 1; i < totalCount; i++) {
                var dup = shapeLayer.duplicate();
                dup.moveAfter(prevLayer);
                
                var dupEffects = dup.property("ADBE Effect Parade");
                if (dupEffects) {
                    for (var e = dupEffects.numProperties; e >= 1; e--) dupEffects.property(e).remove();
                }
                
                var dupGroup = dup.property("ADBE Root Vectors Group").property(params.groupName);
                var dupVectors = dupGroup.property("ADBE Vectors Group");
                
                if (!params.hasSizeSliders) {
                    var cloneRectPath = dupVectors.property("Rect Path");
                    cloneRectPath.property("ADBE Vector Rect Size").expression = masterRef + "content('" + params.groupName + "').content('Rect Path').size";
                    cloneRectPath.property("ADBE Vector Rect Roundness").expression = masterRef + "content('" + params.groupName + "').content('Rect Path').roundness";
                    
                    var cloneFill = dupVectors.property("Fill");
                    cloneFill.property("ADBE Vector Fill Color").expression = masterRef + "content('" + params.groupName + "').content('Fill').color";

                    if (params.hasStroke) {
                        var cloneStroke = dupVectors.property("Stroke");
                        cloneStroke.property("ADBE Vector Stroke Width").expression = masterRef + "content('" + params.groupName + "').content('Stroke').strokeWidth";
                        cloneStroke.property("ADBE Vector Stroke Color").expression = masterRef + "content('" + params.groupName + "').content('Stroke').color";
                    }
                }
                
                var masterShapeTransform = masterRef + "content('" + params.groupName + "').transform.";
                var cloneShapeTransform = dupGroup.property("ADBE Vector Transform Group");
                
                try { cloneShapeTransform.property("ADBE Vector Anchor").expression = masterShapeTransform + "anchorPoint"; } catch(e){}
                try { cloneShapeTransform.property("ADBE Vector Position").expression = masterShapeTransform + "position"; } catch(e){}
                try { cloneShapeTransform.property("ADBE Vector Scale").expression = masterShapeTransform + "scale"; } catch(e){}
                try { cloneShapeTransform.property("ADBE Vector Rotation").expression = masterShapeTransform + "rotation"; } catch(e){}
                try { cloneShapeTransform.property("ADBE Vector Skew").expression = masterShapeTransform + "skew"; } catch(e){}
                try { cloneShapeTransform.property("ADBE Vector Skew Axis").expression = masterShapeTransform + "skewAxis"; } catch(e){}
                try { cloneShapeTransform.property("ADBE Vector Opacity").expression = masterShapeTransform + "opacity"; } catch(e){}
                
                dup.transform.property("ADBE Anchor Point").expression = masterRef + "transform.anchorPoint";
                prevLayer = dup;
            }
        }
    } else {
        shapeLayer.property("Transform").property("Position").expression = godTag + "value;";
    }

    app.endUndoGroup();
}

function getGodRectList() {
    var comp = app.project.activeItem;
    if (!comp || !(comp instanceof CompItem)) return "[]";
    var rects = {};
    for (var i = 1; i <= comp.numLayers; i++) {
        var layer = comp.layer(i);
        if (layer instanceof ShapeLayer) {
            var posProp = layer.property("Transform").property("Position");
            if (posProp.canSetExpression && posProp.expression !== "") {
                var match = posProp.expression.match(/\[GODRECT_TAG:([^\]]+)\]/);
                if (match) rects[match[1]] = true;
            }
        }
    }
    var arr = [];
    for (var k in rects) arr.push(k);
    return JSON.stringify(arr);
}

function killGodRect(masterName) {
    app.beginUndoGroup("Kill GodRects");
    var comp = app.project.activeItem;
    if (!comp) return;
    var toDelete = [];
    for (var i = 1; i <= comp.numLayers; i++) {
        var layer = comp.layer(i);
        if (layer instanceof ShapeLayer) {
            var posProp = layer.property("Transform").property("Position");
            if (posProp.canSetExpression && posProp.expression !== "" && posProp.expression.indexOf("[GODRECT_TAG:" + masterName + "]") !== -1) {
                toDelete.push(layer);
            }
        }
    }
    for (var j = toDelete.length - 1; j >= 0; j--) toDelete[j].remove();
    app.endUndoGroup();
}

function escapeRegExp(string) { return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }

function renameGodRect(oldName, newName) {
    app.beginUndoGroup("Rename GodRects");
    var comp = app.project.activeItem;
    if (!comp) return;
    
    var targetLayers = [];
    for (var i = 1; i <= comp.numLayers; i++) {
        var layer = comp.layer(i);
        if (layer instanceof ShapeLayer) {
            var posProp = layer.property("Transform").property("Position");
            if (posProp.canSetExpression && posProp.expression !== "" && posProp.expression.indexOf("[GODRECT_TAG:" + oldName + "]") !== -1) {
                targetLayers.push(layer);
            }
        }
    }

    var tagRegex = new RegExp("\\[GODRECT_TAG:" + escapeRegExp(oldName) + "\\]", "g");
    var quoteRegex1 = new RegExp("'" + escapeRegExp(oldName) + "'", "g");
    var quoteRegex2 = new RegExp('"' + escapeRegExp(oldName) + '"', "g");

    var propsToUpdate = [];
    for (var j = 0; j < targetLayers.length; j++) {
        collectAndDisableExpressions(targetLayers[j], oldName, newName, tagRegex, quoteRegex1, quoteRegex2, propsToUpdate);
    }

    for (var k = 0; k < targetLayers.length; k++) {
        var layerToRename = targetLayers[k];
        var nameRegex = new RegExp("^" + escapeRegExp(oldName) + "(\\s+\\d+)?$");
        var nameMatch = layerToRename.name.match(nameRegex);
        if (nameMatch) {
            layerToRename.name = newName + (nameMatch[1] || "");
        } else {
            layerToRename.name = layerToRename.name.replace(oldName, newName);
        }
    }

    for (var m = 0; m < propsToUpdate.length; m++) {
        var item = propsToUpdate[m];
        item.prop.expression = item.newExpr;
        item.prop.expressionEnabled = true;
    }
    
    app.endUndoGroup();
}

function collectAndDisableExpressions(propGroup, oldName, newName, tagRegex, quoteRegex1, quoteRegex2, updateList) {
    for (var i = 1; i <= propGroup.numProperties; i++) {
        var prop = propGroup.property(i);
        if (prop.propertyType === PropertyType.PROPERTY) {
            if (prop.canSetExpression && prop.expression !== "") {
                var expr = prop.expression;
                if (expr.indexOf(oldName) !== -1) {
                    var newExpr = expr.replace(tagRegex, "[GODRECT_TAG:" + newName + "]");
                    newExpr = newExpr.replace(quoteRegex1, "'" + newName + "'");
                    newExpr = newExpr.replace(quoteRegex2, '"' + newName + '"');
                    
                    updateList.push({ prop: prop, newExpr: newExpr });
                    prop.expressionEnabled = false; 
                }
            }
        } else if (prop.propertyType === PropertyType.INDEXED_GROUP || prop.propertyType === PropertyType.NAMED_GROUP) {
            collectAndDisableExpressions(prop, oldName, newName, tagRegex, quoteRegex1, quoteRegex2, updateList);
        }
    }
}

function updateGodRectFeatures(masterName, jsonString) {
    app.beginUndoGroup("Update GodRect Features");
    var params = JSON.parse(jsonString);
    var comp = app.project.activeItem;
    if (!comp) return;

    var targetLayers = [];
    var masterLayer = null;

    for (var i = 1; i <= comp.numLayers; i++) {
        var layer = comp.layer(i);
        if (layer instanceof ShapeLayer) {
            var posProp = layer.property("Transform").property("Position");
            if (posProp.canSetExpression && posProp.expression !== "" && posProp.expression.indexOf("[GODRECT_TAG:" + masterName + "]") !== -1) {
                targetLayers.push(layer);
                if (layer.name === masterName) masterLayer = layer;
            }
        }
    }

    if (!masterLayer) { alert("Master layer not found!"); return; }

    // Бронебойная сортировка: Мастер всегда первый, клоны по возрастанию номеров в названии
    targetLayers.sort(function(a, b) {
        if (a === masterLayer) return -1;
        if (b === masterLayer) return 1;
        var numA = 1; var numB = 1;
        var matchA = a.name.match(/\d+$/);
        var matchB = b.name.match(/\d+$/);
        if (matchA) numA = parseInt(matchA[0], 10);
        if (matchB) numB = parseInt(matchB[0], 10);
        return numA - numB;
    });

    var masterRef = "thisComp.layer('" + masterName + "').";
    var hasSizeSliders = params.hasSizeSliders;

    // ШАГ 1: ЗАПЕКАЕМ ТЕКУЩИЕ ЗНАЧЕНИЯ ФИГУРЫ
    var oldStrokeColor = [1, 1, 1, 1]; var oldStrokeWidth = 5; var oldFillColor = [1, 0.2, 0.4, 1];
    var oldSize = [400, 400];
    
    var rootGroupM = masterLayer.property("ADBE Root Vectors Group");
    var contentGroupM = null;
    for (var k = 1; k <= rootGroupM.numProperties; k++) {
        if (rootGroupM.property(k).matchName === "ADBE Vector Group") { contentGroupM = rootGroupM.property(k); break; }
    }
    if (contentGroupM) {
        var vGM = contentGroupM.property("ADBE Vectors Group");
        if (vGM.property("Rect Path")) { try { oldSize = vGM.property("Rect Path").property("ADBE Vector Rect Size").value; } catch(e){} }
        if (vGM.property("Stroke")) { try { oldStrokeColor = vGM.property("Stroke").property("ADBE Vector Stroke Color").value; oldStrokeWidth = vGM.property("Stroke").property("ADBE Vector Stroke Width").value; } catch(e){} }
        if (vGM.property("Fill")) { try { oldFillColor = vGM.property("Fill").property("ADBE Vector Fill Color").value; } catch(e){} }
    }

    // ШАГ 1.5: ДОРАСШИРЕНИЕ ИЛИ СУЖЕНИЕ СЕТКИ
    if (params.hasGrid && params.autoGenGrid) {
        var targetTotal = parseInt(params.gridCols) * parseInt(params.gridRows);
        var currentCount = targetLayers.length;
        
        if (currentCount < targetTotal) {
            // Создаем недостающие
            var prevLayer = targetLayers[targetLayers.length - 1]; 
            for (var a = 0; a < (targetTotal - currentCount); a++) {
                var dup = prevLayer.duplicate();
                dup.moveAfter(prevLayer);
                targetLayers.push(dup); 
                prevLayer = dup;
            }
        } else if (currentCount > targetTotal) {
            // Удаляем лишние с конца (самые новые дубликаты)
            var excess = currentCount - targetTotal;
            for (var b = 0; b < excess; b++) {
                var layerToKill = targetLayers.pop();
                if (layerToKill !== masterLayer) {
                    layerToKill.remove();
                } else {
                    targetLayers.unshift(layerToKill); // Страховка: возвращаем мастер
                    break;
                }
            }
        }
    }

    // ШАГ 2: ХИРУРГИЧЕСКОЕ ОБЕЗВРЕЖИВАНИЕ
    for (var j = 0; j < targetLayers.length; j++) {
        var currentLayer = targetLayers[j];
        var rootGroup = currentLayer.property("ADBE Root Vectors Group");
        var contentGroup = null;
        for (var n = 1; n <= rootGroup.numProperties; n++) {
            if (rootGroup.property(n).matchName === "ADBE Vector Group") { contentGroup = rootGroup.property(n); break; }
        }
        if (contentGroup) {
            var vectorsGroup = contentGroup.property("ADBE Vectors Group");
            var rectPath = vectorsGroup.property("Rect Path");
            if (rectPath) {
                try { 
                    rectPath.property("ADBE Vector Rect Size").expressionEnabled = false; 
                    rectPath.property("ADBE Vector Rect Size").expression = ""; 
                    rectPath.property("ADBE Vector Rect Roundness").expressionEnabled = false; 
                    rectPath.property("ADBE Vector Rect Roundness").expression = ""; 
                } catch(e){}
            }
            for (var p = vectorsGroup.numProperties; p >= 1; p--) {
                if (vectorsGroup.property(p).matchName !== "ADBE Vector Shape - Rect") {
                    vectorsGroup.property(p).remove();
                }
            }
        }
    }

    // ШАГ 3: БЕЗОПАСНАЯ ОЧИСТКА И СИНХРОНИЗАЦИЯ СЛАЙДЕРОВ МАСТЕРА
    var effs = masterLayer.Effects;
    if (hasSizeSliders) {
        var wCtrl = effs.property("Width"); if (!wCtrl) { wCtrl = effs.addProperty("ADBE Slider Control"); wCtrl.name = "Width"; wCtrl.property(1).setValue(oldSize[0]); }
        var hCtrl = effs.property("Height"); if (!hCtrl) { hCtrl = effs.addProperty("ADBE Slider Control"); hCtrl.name = "Height"; hCtrl.property(1).setValue(oldSize[1]); }
        var fc = effs.property("Fill Color"); if (!fc) { fc = effs.addProperty("ADBE Color Control"); fc.name = "Fill Color"; fc.property(1).setValue(oldFillColor); }
        
        if (params.hasStroke) {
            var sc = effs.property("Stroke Color"); if (!sc) { sc = effs.addProperty("ADBE Color Control"); sc.name = "Stroke Color"; sc.property(1).setValue(oldStrokeColor); }
            var sw = effs.property("Stroke Width"); if (!sw) { sw = effs.addProperty("ADBE Slider Control"); sw.name = "Stroke Width"; sw.property(1).setValue(oldStrokeWidth); }
        } else {
            removeEffectSafe(masterLayer, "Stroke Color"); removeEffectSafe(masterLayer, "Stroke Width");
        }
    } else {
        removeEffectSafe(masterLayer, "Width"); removeEffectSafe(masterLayer, "Height");
        removeEffectSafe(masterLayer, "Fill Color"); removeEffectSafe(masterLayer, "Stroke Color"); removeEffectSafe(masterLayer, "Stroke Width");
    }

    if (params.hasConcave) {
        var cr = effs.property("Concave Radius"); if (!cr) { cr = effs.addProperty("ADBE Slider Control"); cr.name = "Concave Radius"; cr.property(1).setValue(40); }
        var cs = effs.property("Concave Smoothness"); if (!cs) { cs = effs.addProperty("ADBE Slider Control"); cs.name = "Concave Smoothness"; cs.property(1).setValue(15); }
    } else {
        removeEffectSafe(masterLayer, "Concave Radius"); removeEffectSafe(masterLayer, "Concave Smoothness");
    }

    if (params.hasBevel) {
        var bs = effs.property("Bevel Size"); if (!bs) { bs = effs.addProperty("ADBE Slider Control"); bs.name = "Bevel Size"; bs.property(1).setValue(30); }
        var bsm = effs.property("Bevel Smoothness"); if (!bsm) { bsm = effs.addProperty("ADBE Slider Control"); bsm.name = "Bevel Smoothness"; bsm.property(1).setValue(10); }
    } else {
        removeEffectSafe(masterLayer, "Bevel Size"); removeEffectSafe(masterLayer, "Bevel Smoothness");
    }

    if (params.hasGrid) {
        var gcl = effs.property("Grid Columns Limit"); if (!gcl) { gcl = effs.addProperty("ADBE Slider Control"); gcl.name = "Grid Columns Limit"; } gcl.property(1).setValue(parseFloat(params.gridCols));
        var ggx = effs.property("Grid Gap X"); if (!ggx) { ggx = effs.addProperty("ADBE Slider Control"); ggx.name = "Grid Gap X"; } ggx.property(1).setValue(parseFloat(params.gridGapX));
        var ggy = effs.property("Grid Gap Y"); if (!ggy) { ggy = effs.addProperty("ADBE Slider Control"); ggy.name = "Grid Gap Y"; } ggy.property(1).setValue(parseFloat(params.gridGapY));
    } else {
        removeEffectSafe(masterLayer, "Grid Columns Limit"); removeEffectSafe(masterLayer, "Grid Gap X"); removeEffectSafe(masterLayer, "Grid Gap Y");
    }

    // ШАГ 4: ПЕРЕСБОРКА ГЕОМЕТРИИ
    var sizeExpr = "";
    if (hasSizeSliders) { sizeExpr = "var s = [" + masterRef + "effect('Width')(1), " + masterRef + "effect('Height')(1)]; "; } 
    else { sizeExpr = "var s = content('" + params.groupName + "').content('Rect Path').size; "; }

    var godTagStr = "/* [GODRECT_TAG:" + masterName + "] */\n";
    var posExpr = "";
    if (params.hasGrid) {
        posExpr = 
            "const baseLayerName = '" + masterName + "';\n" +
            "const isMaster = (thisLayer.name === baseLayerName);\n" +
            "const cols = Math.max(1, thisComp.layer(baseLayerName).effect('Grid Columns Limit')(1));\n" +
            "const baseLayer = thisComp.layer(baseLayerName);\n" +
            "const offset = [baseLayer.effect('Grid Gap X')(1), baseLayer.effect('Grid Gap Y')(1)];\n" +
            "const startPos = isMaster ? value : baseLayer.transform.position;\n" +
            "const masterMatch = baseLayer.name.match(/\\d+$/);\n" +
            "const masterNum = masterMatch ? parseInt(masterMatch[0], 10) : 1;\n" +
            "const matchNum = thisLayer.name.match(/\\d+$/);\n" +
            "const currentNum = matchNum ? parseInt(matchNum[0], 10) : 1;\n" +
            "const myNum = isMaster ? 0 : Math.max(1, currentNum - masterNum);\n" +
            "const myCol = myNum % cols;\n" +
            "const myRow = Math.floor(myNum / cols);\n" +
            "startPos + [myCol * offset[0], myRow * offset[1]];";
    } else {
        posExpr = "value;";
    }

    for (var m = 0; m < targetLayers.length; m++) {
        var cLayer = targetLayers[m];
        var isMasterFlag = (cLayer === masterLayer);
        
        cLayer.property("Transform").property("Position").expression = godTagStr + posExpr;

        var rGroup = cLayer.property("ADBE Root Vectors Group");
        var cGroup = null;
        for (var k = 1; k <= rGroup.numProperties; k++) {
            if (rGroup.property(k).matchName === "ADBE Vector Group") { cGroup = rGroup.property(k); break; }
        }

        if (cGroup) {
            var vGroup = cGroup.property("ADBE Vectors Group");
            
            if (params.hasConcave) {
                var cutsGroup = vGroup.addProperty("ADBE Vector Group"); cutsGroup.name = "Cuts";
                var cutsContents = cutsGroup.property("ADBE Vectors Group");
                var ellipse = cutsContents.addProperty("ADBE Vector Shape - Ellipse");
                ellipse.property("ADBE Vector Ellipse Size").expression = "var r = " + masterRef + "effect('Concave Radius')(1); [r*2, r*2]";
                ellipse.property("ADBE Vector Ellipse Position").expression = sizeExpr + "[-s[0]/2, -s[1]/2]";
                var rep1 = cutsContents.addProperty("ADBE Vector Filter - Repeater"); rep1.property("ADBE Vector Repeater Copies").setValue(2); rep1.property("Transform").property("Position").expression = sizeExpr + "[s[0], 0]";
                var rep2 = cutsContents.addProperty("ADBE Vector Filter - Repeater"); rep2.property("ADBE Vector Repeater Copies").setValue(2); rep2.property("Transform").property("Position").expression = sizeExpr + "[0, s[1]]";
                var mergePaths = vGroup.addProperty("ADBE Vector Filter - Merge"); mergePaths.property("ADBE Vector Merge Type").setValue(3); 
                var offsetInSmooth = vGroup.addProperty("ADBE Vector Filter - Offset"); offsetInSmooth.property("ADBE Vector Offset Amount").expression = masterRef + "effect('Concave Smoothness')(1) * -1";
                var offsetOutSmooth = vGroup.addProperty("ADBE Vector Filter - Offset"); offsetOutSmooth.property("ADBE Vector Offset Line Join").setValue(2); offsetOutSmooth.property("ADBE Vector Offset Amount").expression = masterRef + "effect('Concave Smoothness')(1)";
            }

            if (params.hasBevel) {
                var offsetInBevel = vGroup.addProperty("ADBE Vector Filter - Offset"); offsetInBevel.property("ADBE Vector Offset Amount").expression = masterRef + "effect('Bevel Size')(1) * -1";
                var offsetOutBevel = vGroup.addProperty("ADBE Vector Filter - Offset"); offsetOutBevel.property("ADBE Vector Offset Line Join").setValue(3); offsetOutBevel.property("ADBE Vector Offset Amount").expression = masterRef + "effect('Bevel Size')(1)";
                var roundCorners = vGroup.addProperty("ADBE Vector Filter - RC"); roundCorners.property("ADBE Vector RoundCorner Radius").expression = masterRef + "effect('Bevel Smoothness')(1)";
            }

            if (params.hasStroke) {
                var stroke = vGroup.addProperty("ADBE Vector Graphic - Stroke"); stroke.name = "Stroke";
                if (hasSizeSliders) {
                    stroke.property("ADBE Vector Stroke Color").expression = masterRef + "effect('Stroke Color')(1)";
                    stroke.property("ADBE Vector Stroke Width").expression = masterRef + "effect('Stroke Width')(1)";
                } else {
                    if (isMasterFlag) {
                        stroke.property("ADBE Vector Stroke Color").setValue(oldStrokeColor); 
                        stroke.property("ADBE Vector Stroke Width").setValue(oldStrokeWidth);
                    } else {
                        stroke.property("ADBE Vector Stroke Color").expression = masterRef + "content('" + cGroup.name + "').content('Stroke').color";
                        stroke.property("ADBE Vector Stroke Width").expression = masterRef + "content('" + cGroup.name + "').content('Stroke').strokeWidth";
                    }
                }
            }

            var fill = vGroup.addProperty("ADBE Vector Graphic - Fill"); fill.name = "Fill";
            if (hasSizeSliders) {
                fill.property("ADBE Vector Fill Color").expression = masterRef + "effect('Fill Color')(1)";
            } else {
                if (isMasterFlag) { fill.property("ADBE Vector Fill Color").setValue(oldFillColor); }
                else { fill.property("ADBE Vector Fill Color").expression = masterRef + "content('" + cGroup.name + "').content('Fill').color"; }
            }

            var rp = vGroup.property("Rect Path");
            if (rp) {
                if (hasSizeSliders) {
                    rp.property("ADBE Vector Rect Size").expression = "var w = " + masterRef + "effect('Width')(1); var h = " + masterRef + "effect('Height')(1); [w, h];";
                } else {
                    if (isMasterFlag) {
                        rp.property("ADBE Vector Rect Size").expression = "";
                        rp.property("ADBE Vector Rect Size").setValue(oldSize); 
                    } else {
                        rp.property("ADBE Vector Rect Size").expression = masterRef + "content('" + cGroup.name + "').content('Rect Path').size";
                        rp.property("ADBE Vector Rect Roundness").expression = masterRef + "content('" + cGroup.name + "').content('Rect Path').roundness";
                    }
                }
            }

            if (!isMasterFlag) {
                var masterShapeTransform = masterRef + "content('" + cGroup.name + "').transform.";
                var cloneShapeTransform = cGroup.property("ADBE Vector Transform Group");
                
                try { cloneShapeTransform.property("ADBE Vector Anchor").expression = masterShapeTransform + "anchorPoint"; } catch(e){}
                try { cloneShapeTransform.property("ADBE Vector Position").expression = masterShapeTransform + "position"; } catch(e){}
                try { cloneShapeTransform.property("ADBE Vector Scale").expression = masterShapeTransform + "scale"; } catch(e){}
                try { cloneShapeTransform.property("ADBE Vector Rotation").expression = masterShapeTransform + "rotation"; } catch(e){}
                try { cloneShapeTransform.property("ADBE Vector Skew").expression = masterShapeTransform + "skew"; } catch(e){}
                try { cloneShapeTransform.property("ADBE Vector Skew Axis").expression = masterShapeTransform + "skewAxis"; } catch(e){}
                try { cloneShapeTransform.property("ADBE Vector Opacity").expression = masterShapeTransform + "opacity"; } catch(e){}
                
                cLayer.transform.property("ADBE Anchor Point").expression = masterRef + "transform.anchorPoint";
            }
        }
    }
    app.endUndoGroup();
}